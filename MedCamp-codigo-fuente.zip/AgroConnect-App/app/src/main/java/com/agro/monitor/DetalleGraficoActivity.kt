package com.agro.monitor

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.ValueFormatter
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import java.text.SimpleDateFormat
import java.util.*

class DetalleGraficoActivity : AppCompatActivity() {

    private lateinit var lineChart: LineChart
    private lateinit var tvPromedio: TextView
    private lateinit var tvValorActual: TextView
    private lateinit var tvRango: TextView
    private lateinit var dbRef: DatabaseReference

    private var variableActual: String = "vpd"
    private var horasFiltro: Int = 24
    private var nodoIdActual: String? = null
    private var markerView: CustomMarkerView? = null

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var runnable: Runnable

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detalle_grafico)

        variableActual = intent.getStringExtra("VARIABLE") ?: "vpd"
        val titulo = intent.getStringExtra("TITULO") ?: "DETALLE"
        nodoIdActual = intent.getStringExtra("NODO_ID")

        val tvTitulo = findViewById<TextView>(R.id.tvTituloGrafico)
        tvTitulo?.text = if (!nodoIdActual.isNullOrEmpty()) "$titulo\n$nodoIdActual" else titulo

        lineChart = findViewById(R.id.lineChart)
        tvPromedio = findViewById(R.id.tvPromedio)
        tvValorActual = findViewById(R.id.tvValorActual)
        tvRango = findViewById(R.id.tvRango)

        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: "DdaAJqXxIcadkzamNl16yWyy8k13"
        dbRef = FirebaseDatabase.getInstance().getReference("usuarios").child(uid).child("lecturas")

        configurarGestosGrafico()
        configurarSpinner()

        runnable = object : Runnable {
            override fun run() {
                cargarDatosDesdeFirebase()
                handler.postDelayed(this, 10000)
            }
        }
        handler.post(runnable)
    }

    private fun configurarGestosGrafico() {
        lineChart.apply {
            // --- HABILITAR INTERACCIÓN TÁCTIL Y DESPLAZAMIENTO ---
            setTouchEnabled(true)
            isDragEnabled = true           // Arrastrar con un dedo (Scroll horizontal)
            isScaleXEnabled = true         // Zoom horizontal
            isScaleYEnabled = false        // Escala Y fija para mantener claridad en amplitudes
            setPinchZoom(true)             // Zoom con dos dedos (Pinch-to-zoom)
            isDoubleTapToZoomEnabled = true

            // Inercia suave al deslizar
            isDragDecelerationEnabled = true
            dragDecelerationFrictionCoef = 0.9f

            setBackgroundColor(ContextCompat.getColor(this@DetalleGraficoActivity, R.color.color_card_background))
            description.isEnabled = false
            legend.isEnabled = false
            axisRight.isEnabled = false

            axisLeft.apply {
                textColor = ContextCompat.getColor(this@DetalleGraficoActivity, R.color.color_text_secondary)
                textSize = 10f
                setDrawGridLines(true)
                gridColor = ContextCompat.getColor(this@DetalleGraficoActivity, R.color.color_hero_background)
                gridLineWidth = 1f
                setDrawAxisLine(false)
            }

            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                textColor = ContextCompat.getColor(this@DetalleGraficoActivity, R.color.color_text_secondary)
                textSize = 10f
                setDrawGridLines(false)
                setDrawAxisLine(false)
                setAvoidFirstLastClipping(true)
            }
        }
    }

    private fun configurarSpinner() {
        val spinner = findViewById<Spinner>(R.id.spinnerFiltro)
        val opciones = arrayOf(
            "Última 1h", "Últimas 6h", "Últimas 24h",
            "Últimos 7 días", "Último Mes (30d)", "Últimos 6 Meses", "Último Año"
        )
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, opciones)
        spinner?.adapter = adapter

        spinner?.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                horasFiltro = when (position) {
                    0 -> 1
                    1 -> 6
                    2 -> 24
                    3 -> 168
                    4 -> 720
                    5 -> 4320
                    6 -> 8760
                    else -> 24
                }
                cargarDatosDesdeFirebase()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun cargarDatosDesdeFirebase() {
        val idNodo = nodoIdActual ?: return

        dbRef.child(idNodo).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val listaDatos = mutableListOf<HistorialDataMillis>()
                val ahoraMillis = System.currentTimeMillis()
                val limiteTiempoMillis = ahoraMillis - (horasFiltro * 3600 * 1000L)

                for (child in snapshot.children) {
                    val valor = child.child(variableActual).value?.toString()?.toDoubleOrNull() ?: 0.0
                    val timestampRaw = child.child("timestamp").value?.toString()
                    val fechaRaw = child.child("fecha").value?.toString() ?: child.key ?: ""

                    val timeMillis = obtenerTimestampMillis(timestampRaw, fechaRaw)

                    if (timeMillis >= limiteTiempoMillis || horasFiltro >= 8760) {
                        listaDatos.add(HistorialDataMillis(timestamp = timeMillis, valor = valor))
                    }
                }

                if (listaDatos.isNotEmpty()) {
                    dibujarGraficoReal(listaDatos)
                    actualizarMetricasCabecera(listaDatos)
                } else {
                    lineChart.clear()
                    tvValorActual?.text = "--"
                    tvPromedio?.text = "Prom. --"
                    tvRango?.text = "Rango --"
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("DetalleGrafico", "Error al cargar datos: ${error.message}")
            }
        })
    }

    private fun obtenerTimestampMillis(timestampStr: String?, fechaStr: String): Long {
        timestampStr?.toLongOrNull()?.let { return it }
        val sdfEntrada = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        return try {
            sdfEntrada.parse(fechaStr)?.time ?: System.currentTimeMillis()
        } catch (e: Exception) {
            System.currentTimeMillis()
        }
    }

    private fun actualizarMetricasCabecera(lista: List<HistorialDataMillis>) {
        if (lista.isEmpty()) return
        val unidad = obtenerUnidadVariable(variableActual)
        val ultimoValor = lista.last().valor
        val promedio = lista.sumOf { it.valor } / lista.size
        val minVal = lista.minOf { it.valor }
        val maxVal = lista.maxOf { it.valor }

        tvValorActual?.text = "${String.format("%.1f", ultimoValor)} $unidad"
        tvPromedio?.text = "Prom. ${String.format("%.1f", promedio)} $unidad"
        tvRango?.text = "Rango ${String.format("%.1f", minVal)}–${String.format("%.1f", maxVal)} $unidad"
    }

    private fun dibujarGraficoReal(listaRaw: List<HistorialDataMillis>) {
        val listaOrdenada = listaRaw.sortedBy { it.timestamp }
        if (listaOrdenada.isEmpty()) return

        val primerTimestamp = listaOrdenada.first().timestamp
        val entries = ArrayList<Entry>()

        for (data in listaOrdenada) {
            val xRelativo = (data.timestamp - primerTimestamp).toFloat()
            entries.add(Entry(xRelativo, data.valor.toFloat()))
        }

        val colorLinea = ContextCompat.getColor(this, R.color.color_blue_wave_end)
        val colorFondo = ContextCompat.getColor(this, R.color.color_card_background)
        val colorHighlight = ContextCompat.getColor(this, R.color.color_blue_wave_start)
        val dataSet = LineDataSet(entries, "Historial").apply {
            mode = LineDataSet.Mode.LINEAR
            color = colorLinea
            lineWidth = 2.5f

            setDrawCircles(true)
            setCircleColor(colorLinea)
            circleRadius = 5f
            setDrawCircleHole(true)
            circleHoleColor = colorFondo
            circleHoleRadius = 2.5f

            setDrawFilled(false)

            isHighlightEnabled = true
            highLightColor = colorHighlight
            highlightLineWidth = 1.2f
            setDrawHorizontalHighlightIndicator(true)
            setDrawVerticalHighlightIndicator(true)

            setDrawValues(false)
        }

        lineChart.data = LineData(dataSet)

        val unidad = obtenerUnidadVariable(variableActual)
        if (markerView == null) {
            markerView = CustomMarkerView(this, R.layout.marker_view, primerTimestamp, unidad, horasFiltro)
            lineChart.marker = markerView
        } else {
            markerView?.actualizarBaseData(primerTimestamp, unidad, horasFiltro)
        }

        val sdfSalida = SimpleDateFormat(if (horasFiltro >= 168) "dd/MM" else "HH:mm", Locale.getDefault())
        lineChart.xAxis.apply {
            valueFormatter = object : ValueFormatter() {
                override fun getFormattedValue(value: Float): String {
                    val timestampReal = value.toLong() + primerTimestamp
                    return sdfSalida.format(Date(timestampReal))
                }
            }
        }

        lineChart.apply {
            invalidate()

            // Si hay más de 4 puntos, limita la ventana visible para permitir deslizar con el dedo
            if (entries.size > 4) {
                // Calcula la distancia promedio entre puntos para establecer un rango adecuado
                val rangoTotal = entries.last().x - entries.first().x
                val rangoVisible = (rangoTotal / (entries.size - 1)) * 3.5f

                setVisibleXRangeMaximum(rangoVisible)
                moveViewToX(entries.last().x) // Se ubica en los datos más recientes
            } else {
                fitScreen()
            }
        }
    }

    private fun obtenerUnidadVariable(varName: String): String {
        return when (varName) {
            "vpd" -> "kPa"
            "tempAire", "tempSuelo" -> "°C"
            "humAire", "hum15", "hum40" -> "%"
            "presion" -> "hPa"
            "bateria" -> "V"
            else -> ""
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(runnable)
    }
}

data class HistorialDataMillis(
    val timestamp: Long,
    val valor: Double
)